#include"stdio.h"
int main()
{
    int n,i,j,sp,k=1,st;
    printf("enter the rows");
    scanf("%d",&n);
    st=n-2;
    for(i=1;i<=n;i++)
    {
        //for n number of star 
        if(i==1||i==n)
        {
            for(j=1;j<=n;j++)
            {
                printf("*");
            }
            printf("\n");
        }
        if(i!=1&&i!=n)
        {
            for(j=1;j<=k;j++)
            {
                printf("*");
            }
            for(j=1;j<=st;j++)
            {
                printf(" ");
            }
            for(j=1;j<=k;j++)
            {
                printf("*");
            }
            printf("\n");
        }
        
    }
        
    
}